﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BL_Interface;
using DAO;
using DAO_Interface;
using Entity_Worker;

namespace BL
{
    public class BL_Worker : BL_Worker_Interface
    {
        private Worker_DAO_Interface _workerDao = new Worker_DAO();
        public BL_Worker()
        {
            this._workerDao = new Worker_DAO();
        }
        public void Add(Worker value)
        {
            _workerDao.Add(value);
        }
        public IEnumerable<Worker> GetAll()
        {
            return _workerDao.GetAll();
        }

        public void RemoveAtId(int id)
        {
            _workerDao.RemoveAtId(id);
        }

        public void RemoveAtName(string name)
        {
            _workerDao.RemoveAtName(name);
        }

        public Worker GetInfoUser(int id)
        {
            return _workerDao.GetInfoUser(id);
        }

        public IEnumerable<Worker> GetWorkerAtAccout()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtAccout();
        }

        public IEnumerable<Worker> GetWorkerAtProd()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtProd();
        }

        public IEnumerable<Worker> GetWorkerAtAd()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtAd();
        }

        public IEnumerable<Worker> GetWorkerAtMark()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtMark();
        }

        public IEnumerable<Worker> GetWorkerAtCommon()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtCommon();
        }

        public IEnumerable<Worker> GetWorkerAtManager()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtManager();
        }

        public IEnumerable<Worker> GetWorkerAtDirector()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtDirector();
        }

        public IEnumerable<Worker> GetWorkerAtAccAndCommon()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtAccAndCommon();
        }

        public IEnumerable<Worker> GetWorkerAtAccAndManager()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtAccAndManager();
        }

        public IEnumerable<Worker> GetWorkerAtAccAndDirector()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtAccAndDirector();
        }

        public IEnumerable<Worker> GetWorkerAtProdAndCommon()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtProdAndCommon();
        }

        public IEnumerable<Worker> GetWorkerAtProdAndManager()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtProdAndManager();
        }

        public IEnumerable<Worker> GetWorkerAtProdAndDirector()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtProdAndDirector();
        }

        public IEnumerable<Worker> GetWorkerAtAdAndCommon()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtAdAndCommon();
        }

        public IEnumerable<Worker> GetWorkerAtAdAndManager()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtAdAndManager();
        }

        public IEnumerable<Worker> GetWorkerAtAdAndDirector()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtAdAndDirector();
        }

        public IEnumerable<Worker> GetWorkerAtMarkAndCommon()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtMarkAndCommon();
        }

        public IEnumerable<Worker> GetWorkerAtMarkAndManager()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtMarkAndManager();
        }

        public IEnumerable<Worker> GetWorkerAtMarkAndDirector()
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtMarkAndDirector();
        }

        public IEnumerable<Worker> GetWorkerAtName(string name)
        {
            return (IEnumerable<Worker>)_workerDao.GetWorkerAtName(name);
        }
    }
}
