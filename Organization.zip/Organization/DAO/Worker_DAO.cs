﻿using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;
using DAO_Interface;
using System.Configuration;
using Entity_Worker;

namespace DAO
{
    public class Worker_DAO : Worker_DAO_Interface
    {
        private string _connectionString = ConfigurationManager.ConnectionStrings["Connect"].ConnectionString;
        public void Add(Worker value)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ADD_WORKER";
                cmd.Parameters.AddWithValue(@"Name", value.name);
                cmd.Parameters.AddWithValue(@"Department", value.department);
                cmd.Parameters.AddWithValue(@"Post", value.post);
                var id = new SqlParameter
                {
                    DbType = DbType.Int32,
                    ParameterName = "ID_WORKER",
                    Direction = ParameterDirection.Output
                };
                connection.Open();
                cmd.ExecuteNonQuery();
            }
        }
        public IEnumerable<Worker> GetAll()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_ALL";
                connection.Open();
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker((int)reader["ID_WORKER"],(string)reader["NameWork"],
                                            (string)reader["DEPARTMENT"], (string)reader["POST"]));
                }
            }
            return workers;
        }

        public void RemoveAtId(int id)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "REMOVE_WORKER_AT_ID";
                cmd.Parameters.AddWithValue(@"id_worker", id);
                connection.Open();
                cmd.ExecuteNonQuery();
            }
        }
        public void RemoveAtName(string name)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "REMOVE_WORKER_AT_NAME";
                cmd.Parameters.AddWithValue(@"name", name);
                connection.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public Worker GetInfoUser(int id)
        {
            Worker worker = new Worker();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GetINFO_User";
                cmd.Parameters.AddWithValue(@"ID_WORKER", id);
                connection.Open();
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    worker = (new Worker
                    {
                        id = (int)reader["ID_User"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }
            }
            return worker;
        }
        public IEnumerable<Worker> GetWorkerAtAccout()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_DEP";
                cmd.Parameters.AddWithValue(@"dep", "Accouting");
                connection.Open();
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }
        public IEnumerable<Worker> GetWorkerAtProd()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_DEP";
                cmd.Parameters.AddWithValue(@"dep", "Production");
                connection.Open();
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }

        public IEnumerable<Worker> GetWorkerAtAd()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_DEP";
                cmd.Parameters.AddWithValue(@"dep", "Administration");
                connection.Open();
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }
        public IEnumerable<Worker> GetWorkerAtMark()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_DEP";
                cmd.Parameters.AddWithValue(@"dep", "Marketing");
                connection.Open();
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }
        public IEnumerable<Worker> GetWorkerAtCommon()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_POST";
                cmd.Parameters.AddWithValue(@"post", "Common");
                connection.Open();

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }

        public IEnumerable<Worker> GetWorkerAtManager()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_POST";
                cmd.Parameters.AddWithValue(@"post", "Manager");
                connection.Open();

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }

        public IEnumerable<Worker> GetWorkerAtDirector()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_POST";
                cmd.Parameters.AddWithValue(@"post", "Director");
                connection.Open();

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }
        public IEnumerable<Worker> GetWorkerAtAccAndCommon()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_DEP_AND_POST";
                cmd.Parameters.AddWithValue(@"dep", "Accouting");
                cmd.Parameters.AddWithValue(@"post", "Common");
                connection.Open();

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }
        public IEnumerable<Worker> GetWorkerAtAccAndManager()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_DEP_AND_POST";
                cmd.Parameters.AddWithValue(@"dep", "Accouting");
                cmd.Parameters.AddWithValue(@"post", "Manager");
                connection.Open();

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }
        public IEnumerable<Worker> GetWorkerAtAccAndDirector()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_DEP_AND_POST";
                cmd.Parameters.AddWithValue(@"dep", "Accouting");
                cmd.Parameters.AddWithValue(@"post", "Director");
                connection.Open();

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }
        public IEnumerable<Worker> GetWorkerAtProdAndCommon()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_DEP_AND_POST";
                cmd.Parameters.AddWithValue(@"dep", "Production");
                cmd.Parameters.AddWithValue(@"post", "Common");
                connection.Open();

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }
        public IEnumerable<Worker> GetWorkerAtProdAndManager()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_DEP_AND_POST";
                cmd.Parameters.AddWithValue(@"dep", "Production");
                cmd.Parameters.AddWithValue(@"post", "Manager");
                connection.Open();

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }
        public IEnumerable<Worker> GetWorkerAtProdAndDirector()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_DEP_AND_POST";
                cmd.Parameters.AddWithValue(@"dep", "Production");
                cmd.Parameters.AddWithValue(@"post", "Director");
                connection.Open();

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }
        public IEnumerable<Worker> GetWorkerAtAdAndCommon()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_DEP_AND_POST";
                cmd.Parameters.AddWithValue(@"dep", "Administration");
                cmd.Parameters.AddWithValue(@"post", "Common");
                connection.Open();

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }
        public IEnumerable<Worker> GetWorkerAtAdAndManager()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_DEP_AND_POST";
                cmd.Parameters.AddWithValue(@"dep", "Administration");
                cmd.Parameters.AddWithValue(@"post", "Manager");
                connection.Open();

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }
        public IEnumerable<Worker> GetWorkerAtAdAndDirector()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_DEP_AND_POST";
                cmd.Parameters.AddWithValue(@"dep", "Administration");
                cmd.Parameters.AddWithValue(@"post", "Director");
                connection.Open();

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }

        public IEnumerable<Worker> GetWorkerAtMarkAndCommon()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_DEP_AND_POST";
                cmd.Parameters.AddWithValue(@"dep", "Marketing");
                cmd.Parameters.AddWithValue(@"post", "Common");
                connection.Open();

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }

        public IEnumerable<Worker> GetWorkerAtMarkAndManager()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_DEP_AND_POST";
                cmd.Parameters.AddWithValue(@"dep", "Marketing");
                cmd.Parameters.AddWithValue(@"post", "Manager");
                connection.Open();

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }

        public IEnumerable<Worker> GetWorkerAtMarkAndDirector()
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_DEP_AND_POST";
                cmd.Parameters.AddWithValue(@"dep", "Marketing");
                cmd.Parameters.AddWithValue(@"post", "Director");
                connection.Open();

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }

            }
            return workers;
        }

        public IEnumerable<Worker> GetWorkerAtName(string name)
        {
            List<Worker> workers = new List<Worker>();
            using (var connection = new SqlConnection(_connectionString))
            {
                var cmd = connection.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "GET_AT_NAME";
                cmd.Parameters.AddWithValue(@"name", name);
                connection.Open();
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    workers.Add(new Worker
                    {
                        id = (int)reader["ID_WORKER"],
                        name = (string)reader["NameWork"],
                        department = (string)reader["Department"],
                        post = (string)reader["Post"],
                    });
                }
            }
            return workers;
        }

    }
}
