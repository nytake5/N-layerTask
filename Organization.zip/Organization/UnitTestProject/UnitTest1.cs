﻿using BL;
using BL_Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Entity_Worker;
using PL;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        [ExpectedException(typeof(Exception), "Введите корректные данные!")]
        public void add_user1()
        {
            string name = "Favvula23";
            string dep = "Accouting";
            string post = "Common";
            Worker worker = new Worker(name, dep, post);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception), "Введите корректные данные!")]
        public void add_user2()
        {
            string name = "Favvula";
            string dep = "Accouting145";
            string post = "Common";
            Worker worker = new Worker(name, dep, post);
        }

        [TestMethod]
        public void add_user3()
        {
            string name = "Favvula";
            string dep = "Accouting";
            string post = "";
            Worker worker = new Worker(name, dep, post);
        }
    }
}
