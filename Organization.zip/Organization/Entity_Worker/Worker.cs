﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Entity_Worker
{
    public class Worker
    {
        public int id { get; set; }
        public string name { get; set; }
        public string department { get; set; } 

        public string post { get; set; }

        public Worker() { }

        public Worker(int id, string name, string department, string post)
        {
            Regex regex = new Regex(@"^[a-zA-Zа-яА-Я]*$");
            Match match1 = regex.Match(name);
            Match match2 = regex.Match(department);
            Match match3 = regex.Match(post);
            if (match1.Success && match2.Success && match3.Success && !(match1.Value.Length == 0) &&
                !(match2.Value.Length == 0) && !(match2.Value.Length == 0))
            {
                this.id = id;
                this.name = name;
                this.department = department;
                this.post = post;
            }
            else
                throw new Exception("Введите корректные данные!");
        }

        public Worker(string name, string department, string post)
        {
            Regex regex = new Regex(@"^[a-zA-Zа-яА-Я]*$");
            Match match1 = regex.Match(name);
            Match match2 = regex.Match(department);
            Match match3 = regex.Match(post);
            if (match1.Success && match2.Success && match3.Success && !(match1.Value.Length == 0) &&
                !(match2.Value.Length == 0) && !(match2.Value.Length == 0))
            {
                this.name = name;
                this.department = department;
                this.post = post;
            }
            else
                throw new Exception("Введите корректные данные!");
        }


        public override string ToString()
        {
            return ("id: " + id + " "
                + "name: " + name + " "
                + "department: " + department + " "
                + "post: " + post);
        }
    }
}
