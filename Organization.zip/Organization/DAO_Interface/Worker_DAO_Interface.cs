﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity_Worker;

namespace DAO_Interface
{
    public interface Worker_DAO_Interface
    {
        void Add(Worker worker);
        IEnumerable<Worker> GetAll();
        Worker GetInfoUser(int id);

        IEnumerable<Worker> GetWorkerAtAccout();

        IEnumerable<Worker> GetWorkerAtProd();

        IEnumerable<Worker> GetWorkerAtAd();

        IEnumerable<Worker> GetWorkerAtMark();

        IEnumerable<Worker> GetWorkerAtCommon();

        IEnumerable<Worker> GetWorkerAtManager();

        IEnumerable<Worker> GetWorkerAtDirector();

        IEnumerable<Worker> GetWorkerAtAccAndCommon();

        IEnumerable<Worker> GetWorkerAtAccAndManager();

        IEnumerable<Worker> GetWorkerAtAccAndDirector();

        IEnumerable<Worker> GetWorkerAtProdAndCommon();

        IEnumerable<Worker> GetWorkerAtProdAndManager();

        IEnumerable<Worker> GetWorkerAtProdAndDirector();

        IEnumerable<Worker> GetWorkerAtAdAndCommon();

        IEnumerable<Worker> GetWorkerAtAdAndManager();

        IEnumerable<Worker> GetWorkerAtAdAndDirector();

        IEnumerable<Worker> GetWorkerAtMarkAndCommon();

        IEnumerable<Worker> GetWorkerAtMarkAndManager();

        IEnumerable<Worker> GetWorkerAtMarkAndDirector();

        IEnumerable<Worker> GetWorkerAtName(string name);

        void RemoveAtId(int id);
        void RemoveAtName(string name);
    }
}
