﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity_Worker;
using BL;
using BL_Interface;

namespace PL
{
    public partial class TempDelForm : Form
    {
        private BL_Worker_Interface _workerPl = new BL_Worker();

        public void Set(string name)
        {
            comboBox1.DataSource = _workerPl.GetWorkerAtName(name);
        }
        public TempDelForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Worker delete = (Worker)comboBox1.SelectedItem;
            _workerPl.RemoveAtId(delete.id);
            this.Close();
        }
    }
}
