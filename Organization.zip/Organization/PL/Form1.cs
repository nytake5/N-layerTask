﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BL_Interface;
using BL;
using Entity_Worker;
using System.Text.RegularExpressions;

namespace PL
{
    public partial class Form1 : Form
    {
        private BL_Worker_Interface _workerPl = new BL_Worker();
        public Form1()
        {
            InitializeComponent();
            dataGridView1.DataSource = _workerPl.GetAll();
        }


        public void AddButton_Click(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"^[a-zA-Zа-яА-Я]*$");
            Match match = regex.Match(NameBox.Text);
            if (match.Success && !DepBox.Text.Equals("Department") && !PostBox.Text.Equals("Post"))
            {
                Worker worker = new Worker(NameBox.Text, DepBox.Text, PostBox.Text);
                _workerPl.Add(worker);
            }
            else
                errorProvider1.SetError(RefButton, "Введите данные сотрудника!");
            dataGridView1.DataSource = _workerPl.GetAll();
            NameBox.Clear();
            DepBox.SelectedIndex = 0;
            PostBox.SelectedIndex = 0;
        }

        private void RefButton_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = _workerPl.GetAll();
        }

        private void iDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteFormAtID f = new DeleteFormAtID();
            f.Show();
        }

        private void NameToolStripMenuItem_Click(object sender, EventArgs e)
        {

            DeleteFormAtID f = new DeleteFormAtID();
            f.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void WriteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintForm f = new PrintForm();
            f.Show();
        }
    }
}
