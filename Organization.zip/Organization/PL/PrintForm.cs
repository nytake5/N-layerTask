﻿using BL;
using BL_Interface;
using System;
using System.Windows.Forms;
using Entity_Worker;

namespace PL
{
    public partial class PrintForm : Form
    {
        private BL_Worker_Interface _workerPl = new BL_Worker();
        public PrintForm()
        {
            InitializeComponent();
        }

        private void PrintForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            switch (comboBox1.Text + comboBox2.Text)
            {

                case "Accouting" + "Должность":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtAccout();
                    break;
                case "Production" + "Должность":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtProd();
                    break;
                case "Administration" + "Должность":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtAd();
                    break;
                case "Marketing" + "Должность":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtMark();
                    break;
                case "Accouting" + "Common":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtAccAndCommon();
                    break;
                case "Accouting" + "Manager":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtAccAndManager();
                    break;
                case "Accouting" + "Director":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtAccAndDirector();
                    break;
                case "Production" + "Common":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtProdAndCommon();
                    break;
                case "Production" + "Manager":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtProdAndManager();
                    break;
                case "Production" + "Director":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtProdAndDirector();
                    break;
                case "Administration" + "Common":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtAdAndCommon();
                    break;
                case "Administration" + "Manager":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtAdAndManager();
                    break;
                case "Administration" + "Director":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtAdAndDirector();
                    break;
                case "Marketing" + "Common":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtMarkAndCommon();
                    break;
                case "Marketing" + "Manager":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtMarkAndManager();
                    break;
                case "Marketing" + "Director":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtMarkAndDirector();
                    break;

                default:
                 break;
            }
            comboBox1.Text = "Отдел";
            comboBox2.Text = "Должность";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            switch (comboBox3.Text)
            {
                case "Common":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtCommon();
                    break;
                case "Manager":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtManager();
                    break;
                case "Director":
                    dataGridView1.DataSource = _workerPl.GetWorkerAtDirector();
                    break;
                default:
                    break;
            }
        }

    }
}
