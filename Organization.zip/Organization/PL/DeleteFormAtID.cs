﻿using BL;
using BL_Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity_Worker;

namespace PL
{
    public partial class DeleteFormAtID : Form
    {

        private BL_Worker_Interface _workerPl = new BL_Worker();
        public DeleteFormAtID()
        {
            InitializeComponent();
            comboBox1.DataSource = _workerPl.GetAll();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Worker delete = (Worker)comboBox1.SelectedItem;
            _workerPl.RemoveAtId(delete.id);
            this.Close();
        }

        private void DeleteFormAtID_Load(object sender, EventArgs e)
        {

        }
    }
}
