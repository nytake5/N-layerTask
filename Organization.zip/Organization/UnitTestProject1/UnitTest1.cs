﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using PL;
using Entity_Worker;


namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        [ExpectedException(typeof(Exception), "NOO")]
        public void add_user()
        {
            string name = "Vasia";
            string department = "Marketing";
            string post = "Common";
        }

        [TestMethod]
        private void delete()
        {
            throw new NotImplementedException();
        }
    }
}
