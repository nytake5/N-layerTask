﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity_Worker;
using DAO;
using DAO_Interface;

namespace BL_Interface
{
    public interface BL_Worker_Interface
    {
        void Add(Worker worker);
        IEnumerable<Worker> GetAll();
        IEnumerable<Worker> GetWorkerAtAccout();

        IEnumerable<Worker> GetWorkerAtProd();

        IEnumerable<Worker> GetWorkerAtAd();

        IEnumerable<Worker> GetWorkerAtMark();

        IEnumerable<Worker> GetWorkerAtCommon();

        IEnumerable<Worker> GetWorkerAtManager();

        IEnumerable<Worker> GetWorkerAtDirector();

        IEnumerable<Worker> GetWorkerAtAccAndCommon();

        IEnumerable<Worker> GetWorkerAtAccAndManager();

        IEnumerable<Worker> GetWorkerAtAccAndDirector();

        IEnumerable<Worker> GetWorkerAtProdAndCommon();

        IEnumerable<Worker> GetWorkerAtProdAndManager();

        IEnumerable<Worker> GetWorkerAtProdAndDirector();

        IEnumerable<Worker> GetWorkerAtAdAndCommon();

        IEnumerable<Worker> GetWorkerAtAdAndManager();

        IEnumerable<Worker> GetWorkerAtAdAndDirector();

        IEnumerable<Worker> GetWorkerAtMarkAndCommon();

        IEnumerable<Worker> GetWorkerAtMarkAndManager();

        IEnumerable<Worker> GetWorkerAtMarkAndDirector();

        IEnumerable<Worker> GetWorkerAtName(string name);
        Worker GetInfoUser(int id);
        void RemoveAtId(int id);
        void RemoveAtName(string name);
    }
}
